part of 'signin_bloc.dart';

@immutable
abstract class SigninState {}

class Initial extends SigninState {}

class Loading extends SigninState {}

class Invalid extends SigninState {}

class Valid extends SigninState {}

class Error extends SigninState {
  final String errorMsg;

  Error(this.errorMsg);
}

import 'package:email_validator/email_validator.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'signin_event.dart';
part 'signin_state.dart';

class SigninBloc extends Bloc<SigninEvent, SigninState> {
  SigninBloc() : super(Initial()) {
    on<TextChanged>((event, emit) {
      if (EmailValidator.validate(event.email) == false) {
        emit(Error("Please Enter a Valid Email Address"));
      } else if (event.password.length < 4) {
        emit(Error("Please Enter a Valid Password"));
      } else {
        emit(Valid());
      }
    });
    on<Submitted>((event, emit) {
      emit(Loading());
    });
  }
}

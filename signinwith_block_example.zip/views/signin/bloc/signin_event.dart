part of 'signin_bloc.dart';

@immutable
abstract class SigninEvent {}

class TextChanged extends SigninEvent {
  final String email;
  final String password;

  TextChanged(this.email, this.password);
  
}

class Submitted extends SigninEvent {
  final String email;
  final String password;

  Submitted(this.email, this.password);
  
}

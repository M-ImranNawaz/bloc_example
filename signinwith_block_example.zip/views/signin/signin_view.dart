import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/signin_bloc.dart';

class SiginView extends StatelessWidget {
  SiginView({super.key});

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Signin'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              height: 10,
            ),
            BlocBuilder<SigninBloc, SigninState>(
              builder: (context, state) {
                print('text Change');
                if (state is Error) {
                  return Text(
                    state.errorMsg,
                    style: const TextStyle(color: Colors.red),
                  );
                }
                return const SizedBox();
              },
            ),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: emailController,
              onChanged: (value) {
                BlocProvider.of<SigninBloc>(context).add(
                    TextChanged(emailController.text, passwordController.text));
              },
              decoration: const InputDecoration(
                label: Text('Email Address'),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            TextField(
              controller: passwordController,
              onChanged: (value) {
                BlocProvider.of<SigninBloc>(context).add(
                    TextChanged(emailController.text, passwordController.text));
              },
              decoration: const InputDecoration(
                label: Text('Password'),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            BlocBuilder<SigninBloc, SigninState>(
              builder: (context, state) {
                print('button Click');
                if (state is Loading) {
                  return const Center(
                    child: CircularProgressIndicator.adaptive(),
                  );
                }
                return CupertinoButton(
                  onPressed: state is Valid
                      ? () {
                          BlocProvider.of<SigninBloc>(context).add(Submitted(
                              emailController.text, passwordController.text));
                        }
                      : null,
                  color: state is Valid ? Colors.blue : Colors.grey,
                  child: const Text('Signin'),
                );
              },
            )
          ],
        ),
      ),
    );
  }
}

import 'package:bloc_example/cubits/internet_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HomeView extends StatelessWidget {
  const HomeView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: BlocConsumer<InternetCubit, InternetState>(
          listener: (context, state) {
          },
          builder: (context, state) {
            if (state == InternetState.gained) {
              return const Text('Connected...');
            } else if (state == InternetState.lost) {
              return const Text('Not Connected...');
            } else {
              return const Text('Loading...');
            }
          },
        ),
      ),
    );
  }
}
